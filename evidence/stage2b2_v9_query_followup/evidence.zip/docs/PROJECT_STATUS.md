# Project status — 2B.2 follow-up, 2026-10-14

Stages 1 and 2A are accepted as audit/planning and a reproducible offline baseline.
Stage 2B.1 is accepted as an engineering improvement in temporal evidence,
provenance and per-stream selection. Its event timing and lamp semantics have
not been independently validated. Accepted A–D and event-level recording-6
diagnostics are preserved; they were not repeated for 2B.2.

2B.2 adds conservative result semantics and abstention; it does not improve or
retrain phase discovery. Physical UNKNOWN is reported separately from model
history coverage. External vehicle-event and lamp validation remain open.
Known regressions (including recording 6 K 2→3 and degraded boundary results
after changed evidence ingestion) remain in the unchanged
`benchmarks/stage2b1_20261013/comparison.json`. No parameters were selected to
repair these results.

Production base: `afcfaa2b38e106201d7e819570425acfc4c5487f`.
Only uncertainty/structured-abstention code and its tests were taken from
`1207344bdcbc46edbf19bace65382ee0252d1f4d`; diagnostic runners/artifacts were
not used as the production base. Main remains unchanged.

Top-level `millis`: according to the supplied description from `Инфо.docx`,
this is the time when the vehicle left the intersection. This is provided field
semantics, not a measured stop-line crossing. Camera/controller synchronization,
endpoint timing accuracy and the relation to the stop line remain unverified.
The historical `millis - move_duration_millis` calculation remains a proxy.

The canonical V9 core renderer now delegates to the shared state contract.
Prepared immutable history supports repeated queries without repeated validation.
Malformed histories give UNKNOWN/INVALID_PHASE_HISTORY; valid gaps/out-of-range
queries give UNKNOWN/NO_TEMPORAL_COVERAGE. Explicit configured/simulated modes
remain distinct from reconstructed physical states. Follow-up base:
`8bb7ca1a9d8137001028f2c6b6e8e6af98d42201`.
